# Textos de los carruseles

## 1_hola_soy_tino

👋 ¡Hola! Soy Tino.

Pesco en mar y en río y aquí te cuento, en menos de un minuto, los trucos que de verdad funcionan en España: lubina, dorada, calamar, black bass, lucio, carpa… y también la historia de los peces y de la pesca.

✅ Datos contrastados con fuentes (MITECO, CSIC, BOE, MAPA).
✅ Sin mitos ni inventos.
✅ Siempre con la normativa al día.

¿Te vienes de pesca? Sígueme y guarda los trucos 📌

#pesca #pescaespaña #pescaenelmar #pescaderio #topfishingtips

---

## 2_que_vas_a_aprender

Esto es lo que vas a aprender aquí 👇

🌊 MAR: calamar, sepia, lubina, dorada, sargo.
🏞️ RÍO: black bass, lucio, siluro, carpa, barbo.
🪢 TÉCNICA: nudos, cómo leer la playa, mareas y luna.
📜 HISTORIA: cómo llegaron las especies invasoras, la almadraba, anzuelos de 23.000 años…

Un truco nuevo cada día. Sígueme para no perdértelos 🎣

#pesca #pescaespaña #blackbass #lubina #carpfishing #topfishingtips

---

## 3_reglas_antes_de_pescar

5 reglas antes de salir a pescar ✅

1️⃣ Licencia: la de mar y la de río son distintas. La de tu comunidad o la interautonómica (10 comunidades).
2️⃣ Tallas mínimas, vedas y cupos: cambian según la comunidad.
3️⃣ Mira mareas y previsión: con temporal no se pesca en roca.
4️⃣ Especies invasoras: nunca las sueltes en otras aguas ni las transportes vivas.
5️⃣ Seguridad: chaleco, buen calzado, nunca de espaldas al mar y mejor acompañado.

📌 Guárdalo y compártelo con tu compañero de pesca.

#pesca #pescaresponsable #pescaespaña #licenciadepesca #topfishingtips

---

